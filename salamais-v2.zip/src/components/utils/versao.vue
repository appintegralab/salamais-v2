<template>
    <span>
        <span>versão</span>
        <span class="rounded border ml-1 px-1 finter text-[8pt] fw-500 border-white">
            22.6.24.16.00
        </span>
    </span>
</template>
<script>
export default {

}
</script>
<style lang="">
    
</style>